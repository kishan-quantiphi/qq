#!/bin/bash
rm -rf /home/ubuntu/www/*
apt-get update
apt-get install -y python3-pip
apt-get install -y nginx
apt-get install -y supervisor
apt-get install -y python3-dev
apt-get install -y python3-dev libmysqlclient-dev
# sudo /etc/init.d/nginx stop


pip3 install virtualenv
virtualenv /home/ubuntu/www/project-venv
source /home/ubuntu/www/project-venv/bin/activate
install gunicorn
pip install -r /home/ubuntu/www/project/requirements.txt

cd /home/ubuntu/www/project
python manage.py makemigrations
python manage.py migrate
# sudo cp /home/ubuntu/www/project/gunicorn.conf /etc/supervisor/conf.d/gunicorn.conf
echo "[program:gunicorn]" >> /etc/supervisor/conf.d/gunicorn.conf
echo "derectory=/home/ubuntu/www/project" >> /etc/supervisor/conf.d/gunicorn.conf
echo "command=/home/ubuntu/www/project-env/bin/gunicorn --workers 3 --bind unix:/home/ubuntu/www/project/app.sock ebdjango.wsgi.application" >> /etc/supervisor/conf.d/gunicorn.conf
echo "autostart=true" >> /etc/supervisor/conf.d/gunicorn.conf
echo "autorestart=true" >> /etc/supervisor/conf.d/gunicorn.conf
echo "stderr_logfile=/var/log/gunicorn/gunicorn.err.log" >> /etc/supervisor/conf.d/gunicorn.conf
echo "stdout_logfile=/var/log/gunicorn/gunicorn.out.log" >> /etc/supervisor/conf.d/gunicorn.conf
echo "[group:guni]" >> /etc/supervisor/conf.d/gunicorn.conf
echo "programs:gunicorn" >> /etc/supervisor/conf.d/gunicorn.conf
sudo mkdir /var/log/gunicorn 
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl status
cd /etc/nginx/sites-available
sudo cp /home/ubuntu/www/project/django.conf /etc/nginx/sites-available/django.conf
sudo nginx -t
sudo ln /etc/nginx/sites-available/django.conf /etc/nginx/sites-enabled/
sudo nginx -t


#!/bin/bash
#nginx startup
cd /home/ubuntu/www/project/
source /home/ubuntu/www/project-venv/bin/activate
echo yes | /home/ubuntu/www/project/manage.py collectstatic
sudo service nginx restart
