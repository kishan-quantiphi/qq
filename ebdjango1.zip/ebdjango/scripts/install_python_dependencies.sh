#!/bin/bash
#python
sudo pip3 install virtualenv
sudo virtualenv /home/ubuntu/www/project-venv
sudo source /home/ubuntu/www/project-venv/bin/activate
pip install gunicorn
pip install -r /home/ubuntu/www/project/requirements.txt
