#!/bin/bash
#nginx
sudo cp /home/ubuntu/www/project/gunicorn.conf /etc/init/gunicorn.conf
sudo service gunicorn start

# sudo mkdir /var/log/gunicorn
# sudo supervisorctl reread
# sudo supervisorctl update
# sudo supervisorctl status
# cd /etc/nginx/sites-available
sudo cp /home/ubuntu/www/project/django.conf /etc/nginx/sites-available/django.conf
# sudo nginx -t
sudo ln -s /etc/nginx/sites-available/django.conf /etc/nginx/sites-enabled
# sudo ln /etc/nginx/sites-available/django.conf /etc/nginx/sites-enabled/
sudo nginx -t
