#!/bin/bash
rm -rf /home/ubuntu/www/*
