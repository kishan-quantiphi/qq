#!/bin/bash
sudo apt-get update
sudo apt-get install -y python3-pip
sudo apt-get install -y nginx
# sudo apt-get install -y supervisor
sudo apt-get install -y python3-dev
sudo apt-get install -y python3-dev libmysqlclient-dev
