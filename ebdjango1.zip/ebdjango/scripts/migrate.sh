#!/bin/bash
#django migrate
cd /home/ubuntu/www/project/
source /home/ubuntu/www/project-venv/bin/activate
./manage.py makemigrations
./manage.py migrate
