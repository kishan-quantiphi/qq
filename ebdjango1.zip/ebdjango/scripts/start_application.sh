#!/bin/bash
#nginx startup
cd /home/ubuntu/www/project/
source /home/ubuntu/www/project-venv/bin/activate
echo yes | /home/ubuntu/www/project/manage.py collectstatic
sudo service nginx restart
