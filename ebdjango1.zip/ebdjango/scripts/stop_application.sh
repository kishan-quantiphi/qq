#!/bin/bash
cd /home/ubuntu/www/project/
source /home/ubuntu/www/project-venv/bin/activate
sudo service nginx stop
# supervisorctl -c /home/ubuntu/www/project/supervisor/default.conf stop all 2&>1 >/dev/null
# sudo unlink /tmp/supervisor.sock 2> /dev/null
# sudo pkill supervisor*
